require 'test_helper'

class SearchpageControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get searchpage_index_url
    assert_response :success
  end

  test "should get results" do
    get searchpage_results_url
    assert_response :success
  end

end
