class SearchpageController < ApplicationController
  def index
  end

  def results
  end
end
