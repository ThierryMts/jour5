module SearchpageHelper
end
