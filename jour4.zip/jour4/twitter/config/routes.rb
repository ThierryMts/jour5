Rails.application.routes.draw do
  get 'home/homepage'
  resource :home
end
