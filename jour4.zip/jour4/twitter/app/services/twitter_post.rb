class TwitterPost
	def initialize(params)
		@contenu = params[:contenu]
 	end

 	def log_in_to_twitter
		client = Twitter::REST::Client.new do |config|  
  config.consumer_key = "5rpf1MBQO2SikCoyW4NLPxtZd"
  config.consumer_secret     = "sSaGRohg8l5cOSEodUM0fpI7WZRuVul7GJNAR7dwaKUJZdg3j9"
  config.access_token        = "918103723557179392-AnjiXh206Xburoz5F2eviVNZsKLEqIE"
  config.access_token_secret = "qWfmvldkNVcJdsdHjGOOqIJr8daJHBg56aRuSzRTV3Nyz" 		
 	end

 	def send_tweet
 	SendTweet.new = client.update
 	end
 end