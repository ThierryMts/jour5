class HomeController < ApplicationController
  def homepage
  end
end
